# Sai Nikhil Balusu — Personal Website

## Files
- `index.html` — website content
- `style.css` — design and responsive styling

## Free hosting
This static website can be published for free using GitHub Pages, Netlify, or Cloudflare Pages.

## Before publishing
Replace:
- `your-email@example.com`
- `+91 XXXXX XXXXX`

with the real contact details you want displayed publicly.
